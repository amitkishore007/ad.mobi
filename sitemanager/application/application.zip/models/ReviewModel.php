<?php


/**
* 
*/
class ReviewModel extends CI_Model
{
	
	// public function get_all_reviews() {

		
	// }

	// public function get_review($id) {

	// 	$q = $this->db->select('reviews.user_id,reviews.rating,reviews.created_at,reviews.comment,users.username')->where(['product_id'=>$id])->join('users','users.id = reviews.user_id')->order_by('reviews.created_at','DESC')->get('reviews');

	// 	if ($q->num_rows()) {
			
	// 		return $q->result();
	// 	}

	// }
		
}