<?php 

// if ( ! defined('BASEPATH')) exit('No direct script access allowed');


// if (!function_exists('send_email')) {


// 	function send_email($to, $from,$subject,$) {



// 	}
// }