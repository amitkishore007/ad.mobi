
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                          <div class="container">
                                <div class="page-content-inner">
                                    <div class="mt-content-body">
                                        
                                       <!-- start row -->
                        
                        <div class="row">
                            <div class="col-md-12">
                                <form class="form-horizontal form-row-seperated" action="#">
                                    <div class="portlet light bordered">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <i class="fa fa-shopping-cart"></i>Vandor <span class="text-center alert alert-success success-msg"></span></div>
                                            <div class="actions">
                                            <div class="btn-group btn-group-devided">
                                                <a class="btn btn-transparent dark btn-outline btn-circle btn-sm " href='<?php echo base_url('admin/create') ?>'>
                                                    Create new vandor</a>
                                               
                                            </div>
                                        </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="tabbable-bordered">
                                                <ul class="nav nav-tabs">
                                                   
                                                    
                                                   
                                                </ul>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_general">
                                                        <div class="form-body">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">username:
                                                                    <span class="required"> * </span>
                                                                </label>
                                                                <div class="col-md-10"> 
                                                                    <input type="text" class="form-control vandor_name"  name="andor[name]" placeholder="username"> 

                                                                     <span class="text-danger  vandor_name-error"></span>   
                                                                    </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">Email:
                                                                    <span class="required"> * </span>
                                                                </label>
                                                                <div class="col-md-10"> 
                                                                    <input type="text" class="form-control vandor_email"  name="vandor[email]" placeholder="Email"> 

                                                                     <span class="text-danger  vandor_email-error"></span>   
                                                                    </div>
                                                            </div>
                                                           <div class="form-group">
                                                                <label class="col-md-2 control-label">Password:
                                                                    <span class="required"> * </span>
                                                                </label>
                                                                <div class="col-md-10"> 
                                                                    <input type="password" class="form-control vandor_password"  name="vandor[password]" placeholder="Password"> 

                                                                     <span class="text-danger  vandor_password-error"></span>   
                                                                    </div>
                                                            </div>

                                                              <div class="form-group">
                                                                <label class="col-md-2 control-label">Retype Password:
                                                                    <span class="required"> * </span>
                                                                </label>
                                                                <div class="col-md-10"> 
                                                                    <input type="password" class="form-control vandor_retype"  name="vandor[retype]" placeholder="Retype password"> 

                                                                     <span class="text-danger  vandor_retype-error"></span>   
                                                                    </div>
                                                            </div>
                                                        
                                                          
                                                            

                                                          

                                                            <div class="form-group">
                                                            <label class="col-md-2 control-label">
                                                                    <span class="required"> &nbsp; </span>
                                                                </label>
                                                                <div class="col-md-10">
                                                                    <button type="button" data-loading-text="Loading..." class="btn btn-primary btn-lg mt-ladda-btn ladda-button mt-progress-demo create-vandor" data-style="expand-left">
                                                                        <span class="ladda-label">Submit</span>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- end row -->
                        
                                    </div>
                                </div>
                            </div>

                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
          