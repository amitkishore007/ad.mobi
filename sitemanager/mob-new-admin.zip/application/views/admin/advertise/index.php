
        <!-- BEGIN CONTENT -->
        <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY -->
            <div class="page-content">
                <!-- BEGIN PAGE HEADER-->
                <!-- BEGIN PAGE TITLE-->
               
                 <div class="container">
                        <div class="page-content-inner">
                            <div class="mt-content-body">
                                
                               <div class="row">
                                   <div class="col-md-12 ">
                    <!-- BEGIN Portlet PORTLET-->
                    <div class="portlet light bordered">
                        <div class="portlet-title tabbable-line">
                            <div class="caption">
                                <i class="icon-pin font-yellow-lemon"></i>
                                <!-- <span class="caption-subject bold font-yellow-lemon uppercase"> Manage Payments </span> -->
                                <!-- <span class="caption-helper">more samples...</span> -->
                            </div>
                            <ul class="nav nav-tabs order-tabs">
                                <li class="active">
                                    <a href="#portlet_tab1" data-toggle="tab">Advertise with us</a>
                                </li>
                                
                                
                            </ul>
                        </div>
                        <div class="portlet-body">
                            <div class="tab-content">
                              
                                 
                                <div class="tab-pane active" id="portlet_tab1">
                                    <div class="row">
                                            <div class="col-md-12 ">
                                                <!-- BEGIN Portlet PORTLET-->
                                                <div class="portlet box blue-hoki">
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-gift"></i>Coming soon</div>
                                                     
                                                    </div>
                                                    <div class="portlet-body payment-settled">
                                                        <div class="scroller" style="height:200px" data-rail-visible="1" data-rail-color="yellow" data-handle-color="#a1b2bd">
                                                           <strong>Coming soon</strong>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END Portlet PORTLET-->
                                            </div>
                                           
                                        </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                               </div>
                
                            </div>
                        </div>
                    </div>

            </div>
            <!-- END CONTENT BODY -->
        </div>
        <!-- END CONTENT -->
