    
            </div>
            </div>
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
          <div class="page-wrapper-row">
                <div class="page-wrapper-bottom">
                    <!-- BEGIN FOOTER -->
                 
                    <!-- BEGIN INNER FOOTER -->
                    <div class="page-footer">
                        <div class="container"> 2017 © mobicharge.co.in by
                            <a target="_blank" href="http://www.instasofttech.com/">Insta Soft Tech</a> &nbsp;|&nbsp;
                           
                        </div>
                    </div>
                    <div class="scroll-to-top" style="display: block;">
                        <i class="icon-arrow-up"></i>
                    </div>
                    <!-- END INNER FOOTER -->
                    <!-- END FOOTER -->
                </div>
            </div>
            <!-- END FOOTER -->
        </div>
       
        
        <!--[if lt IE 9]>
<script src="<?php //echo base_url('assets/global/plugins/respond.min.js'); ?>"></script>
<script src="<?php //echo base_url('assets/global/plugins/excanvas.min.js'); ?>../assets/global/plugins/excanvas.min.js"></script> 
<script src="<?php //echo base_url('assets/global/plugins/ie8.fix.min.js'); ?>../assets/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
           <!-- BEGIN CORE PLUGINS -->
           <script src="<?php echo base_url('assets/global/plugins/jquery.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/js.cookie.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/jquery.blockui.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js'); ?>" type="text/javascript"></script>
           <!-- END CORE PLUGINS -->
           <!-- BEGIN PAGE LEVEL PLUGINS -->
           <script src="<?php echo base_url('assets/global/scripts/datatable.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/fancybox/source/jquery.fancybox.pack.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/plupload/js/plupload.full.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/fuelux/js/spinner.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-touchspin/bootstrap.touchspin.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-markdown/lib/markdown.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-summernote/summernote.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/ladda/spin.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/ladda/ladda.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-confirmation/bootstrap-confirmation.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/jstree/dist/jstree.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/dropzone/dropzone.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/form-dropzone.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/jquery-minicolors/jquery.minicolors.min.js'); ?>" type="text/javascript"></script>
        
             <script src="<?php echo base_url('assets/global/plugins/icheck/icheck.min.js');?>" type="text/javascript"></script>
      
           
           <!-- END PAGE LEVEL PLUGINS -->
           <!-- BEGIN PAGE LEVEL SCRIPTS -->
           <script src="<?php echo base_url('assets/pages/scripts/table-datatables-fixedheader.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/select2/js/select2.full.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/components-bootstrap-touchspin.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/components-editors.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/ui-buttons-spinners.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/jquery-nestable/jquery.nestable.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/ui-confirmations.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/global/plugins/bootstrap-toastr/toastr.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/components-color-pickers.min.js'); ?>" type="text/javascript"></script>
          
           

            <!-- END PAGE LEVEL SCRIPTS -->
           <!-- BEGIN THEME GLOBAL SCRIPTS -->
           <script src="<?php echo base_url('assets/global/scripts/app.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/ecommerce-products-edit.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/components-select2.min.js'); ?>" type="text/javascript"></script>
           <!-- <script src="<?php echo base_url('assets/pages/scripts/ui-nestable.min.js'); ?>../assets/pages/scripts/ui-nestable.min.js" type="text/javascript"></script> -->
           <script src="<?php echo base_url('assets/pages/scripts/ui-tree.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/pages/scripts/dashboard.min.js'); ?>" type="text/javascript"></script>
           
           <!-- END THEME GLOBAL SCRIPTS -->
           <!-- BEGIN THEME LAYOUT SCRIPTS -->
           <script src="<?php echo base_url('assets/layouts/layout3/scripts/layout.min.js'); ?>" type="text/javascript"></script>
           <script src="<?php echo base_url('assets/layouts/layout3/scripts/demo.min.js'); ?>" type="text/javascript"></script>
           
           <!-- END THEME LAYOUT SCRIPTS -->
           
           <script type='text/javascript'>
             
              var ajax_url = "<?php echo base_url(); ?>";
           
           </script>
           <script src='<?php echo base_url('assets/js/jquery.form.js'); ?>'></script>
           <script src='<?php echo base_url('assets/js/star_rating.js'); ?>'></script>
           <script src='<?php echo base_url('assets/js/script.js'); ?>'></script>
   
</body>



</html>